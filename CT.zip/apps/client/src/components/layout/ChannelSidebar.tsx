import { useState, useEffect, useCallback } from 'react';
import axios from 'axios';
import { Hash, Volume2, Settings, Plus, Radio, Grid, Globe } from 'lucide-react';
import { getServerUrl } from '../../utils/apiConfig';
import { UserBottomBar } from './UserBottomBar';
// Importiere CreateChannelModal...

// Interfaces wie im Original...

export const ChannelSidebar = ({ serverId, activeChannelId, onSelectChannel }: any) => {
  const [categories, setCategories] = useState<any[]>([]);
  const [uncategorized, setUncategorized] = useState<any[]>([]);
  const [serverName, setServerName] = useState('LOADING...');
  // UI States...

  // Dein Fetch Code (fetchData) bleibt identisch...

  const renderChannel = (c: any) => {
    const isActive = activeChannelId === c.id;
    const Icon = c.type === 'web' ? Globe : c.type === 'voice' ? Radio : Hash;
    
    return (
      <div key={c.id} onClick={() => onSelectChannel(c)}
        className={`group flex items-center px-4 py-1.5 cursor-pointer text-sm transition-all border-l-2
          ${isActive 
            ? 'border-cyan-400 bg-cyan-900/20 text-cyan-300' 
            : 'border-transparent text-gray-500 hover:text-cyan-100 hover:bg-white/5 hover:border-gray-600'}
        `}
      >
        <Icon size={14} className={`mr-3 ${isActive ? 'animate-pulse' : ''}`} />
        <span className="tracking-wide opacity-90 font-mono">{c.name}</span>
      </div>
    );
  };

  return (
    <div className="flex flex-col h-full bg-transparent">
        {/* HEADER */}
        <div className="h-16 flex items-center px-6 border-b border-cyan-900/30">
          <Grid className="w-5 h-5 text-cyan-500 mr-3" />
          <div className="overflow-hidden">
              <h1 className="text-sm font-bold tracking-[0.2em] text-white uppercase truncate">{serverName}</h1>
              <div className="text-[10px] text-cyan-700 tracking-wider">COMMAND SECTOR</div>
          </div>
          <Settings size={14} className="ml-auto text-gray-600 hover:text-cyan-400 cursor-pointer" />
        </div>

        {/* LISTE */}
        <div className="flex-1 overflow-y-auto pt-6 space-y-6 px-0 custom-scrollbar">
          
           {/* Unkategorisiert -> "PRIORITY COMMS" */}
           {uncategorized.length > 0 && (
               <div>
                   <h3 className="text-[10px] font-bold text-cyan-700 uppercase tracking-widest px-6 mb-2 flex items-center">
                       <span className="w-1.5 h-1.5 bg-cyan-500 rounded-full mr-2"></span> Priority
                   </h3>
                   {uncategorized.map(renderChannel)}
               </div>
           )}

           {/* Kategorien */}
           {categories.map(cat => (
             <div key={cat.id}>
                <div className="px-6 mb-2 flex items-center justify-between group cursor-pointer">
                    <h3 className="text-[10px] font-bold text-gray-600 uppercase tracking-widest hover:text-cyan-600 transition-colors">
                        // {cat.name}
                    </h3>
                    <Plus size={12} className="text-gray-700 hover:text-cyan-400 opacity-0 group-hover:opacity-100" />
                </div>
                <div>{cat.channels.map(renderChannel)}</div>
             </div>
           ))}
        </div>
        
        {/* USER FOOTER */}
        <div className="border-t border-cyan-900/30">
            <UserBottomBar />
        </div>
    </div>
  );
};