import { useState, useRef } from 'react';
import classNames from 'classnames';
import { ChevronLeft, ChevronRight, Command, Wifi } from 'lucide-react';

// Components
import { ServerRail } from './ServerRail';
import { BottomChatBar, BottomChatBarRef } from './BottomChatBar';
import { MemberSidebar } from './MemberSidebar';
import { ChannelSidebar } from './ChannelSidebar';
import { WebChannelView } from '../server/WebChannelView';
// ... andere Imports

export const MainLayout = () => {
  const [showLeftSidebar, setShowLeftSidebar] = useState(true);
  const [showRightSidebar, setShowRightSidebar] = useState(true);
  const [selectedServerId, setSelectedServerId] = useState<number | null>(null);
  const [activeChannel, setActiveChannel] = useState<any | null>(null);
  const chatBarRef = useRef<BottomChatBarRef>(null);

  const handleServerSelect = (id: number | null) => {
      setSelectedServerId(id);
      setActiveChannel(null); 
  };

  return (
    // Hintergrund: Tiefes Zinc mit Noise-Textur für "Kino-Feeling"
    <div className="flex h-screen w-screen bg-command-base text-command-text font-sans antialiased overflow-hidden relative selection:bg-command-accent/30 selection:text-white">
      
      {/* Ambient Background Glow (Subtil) */}
      <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] bg-command-accent/5 blur-[120px] rounded-full pointer-events-none" />
      <div className="absolute bottom-[-10%] right-[-10%] w-[30%] h-[30%] bg-blue-600/5 blur-[100px] rounded-full pointer-events-none" />

      {/* 1. SERVER RAIL (Floating Dock Style) */}
      <div className="z-50 relative py-4 pl-3">
        <div className="h-full bg-command-surface/50 backdrop-blur-xl border border-white/5 rounded-2xl shadow-2xl">
            <ServerRail 
                selectedServerId={selectedServerId} 
                onSelectServer={handleServerSelect} 
            />
        </div>
      </div>

      {/* 2. SIDEBAR (Glass Panel) */}
      <div className={classNames(
          "transition-all duration-500 ease-[cubic-bezier(0.32,0.72,0,1)] relative z-40 py-4 ml-2", 
          showLeftSidebar ? "w-64 opacity-100 translate-x-0" : "w-0 opacity-0 -translate-x-4 overflow-hidden"
        )}> 
        <div className="h-full w-64 bg-command-panel/80 backdrop-blur-md border border-white/5 rounded-2xl flex flex-col overflow-hidden shadow-xl">
           {selectedServerId ? (
               <ChannelSidebar 
                  serverId={selectedServerId}
                  activeChannelId={activeChannel?.id || null} 
                  onSelectChannel={(c: any) => {
                      if (c.type === 'voice' || c.type === 'web') setActiveChannel(c);
                      else chatBarRef.current?.openChat(c.id, c.name);
                  }}
               />
           ) : (
               <div className="p-4 text-command-muted">Dashboard Placeholder</div>
           )}
        </div>
      </div>

      {/* 3. MAIN CONTENT */}
      <div className="flex-1 flex flex-col min-w-0 relative mx-2 my-4 bg-command-panel/30 border border-white/5 rounded-2xl backdrop-blur-sm overflow-hidden shadow-2xl">
        
        {/* Header Bar */}
        <div className="h-14 border-b border-white/5 flex items-center justify-between px-6 bg-white/[0.02]">
            <div className="flex items-center gap-3">
                <div className={`w-2 h-2 rounded-full ${selectedServerId ? 'bg-green-500 shadow-[0_0_8px_rgba(34,197,94,0.4)]' : 'bg-gray-600'}`}></div>
                <span className="text-sm font-medium tracking-wide text-gray-400">
                    {activeChannel ? activeChannel.name : 'System Ready'}
                </span>
            </div>
            <div className="flex items-center gap-4 text-xs font-mono text-command-muted">
                 <div className="flex items-center gap-1.5 px-2 py-1 rounded bg-white/5 border border-white/5">
                    <Wifi size={10} />
                    <span>SECURE LINK</span>
                 </div>
                 <span>v2.4.0</span>
            </div>
        </div>

        {/* Content View */}
        {selectedServerId && activeChannel?.type === 'web' ? (
            <WebChannelView channelId={activeChannel.id} channelName={activeChannel.name} />
        ) : (
            <div className="flex-1 flex flex-col items-center justify-center text-center">
                 <div className="w-24 h-24 bg-gradient-to-tr from-command-surface to-command-panel rounded-3xl border border-white/10 flex items-center justify-center shadow-2xl mb-6 group cursor-default">
                    <Command className="w-10 h-10 text-command-muted group-hover:text-command-accent transition-colors duration-500" />
                 </div>
                 <h2 className="text-xl font-medium text-white mb-2 tracking-tight">Awaiting Command</h2>
                 <p className="text-command-muted text-sm max-w-md leading-relaxed">
                    Select a channel from the sidebar or initialize a new sequence via the command terminal.
                 </p>
            </div>
        )}

        <BottomChatBar ref={chatBarRef} />
      </div>

      {/* 4. RECHTE SIDEBAR */}
      <div className={classNames(
          "transition-all duration-500 ease-[cubic-bezier(0.32,0.72,0,1)] relative z-40 py-4 mr-3", 
          selectedServerId && showRightSidebar ? "w-64 opacity-100 translate-x-0" : "w-0 opacity-0 translate-x-4 overflow-hidden"
        )}>
        {selectedServerId && (
             <div className="h-full w-64 bg-command-panel/80 backdrop-blur-md border border-white/5 rounded-2xl overflow-hidden shadow-xl">
                <MemberSidebar serverId={selectedServerId} />
            </div>
        )}
      </div>

    </div>
  );
};