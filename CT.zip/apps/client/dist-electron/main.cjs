"use strict";
const electron = require("electron");
const path = require("path");
const Database = require("better-sqlite3");
const userDataPath = electron.app.getPath("userData");
const dbPath = path.join(userDataPath, "local-chat.db");
let win;
try {
  const db = new Database(dbPath);
  db.exec("CREATE TABLE IF NOT EXISTS messages (id INTEGER PRIMARY KEY, content TEXT)");
  electron.ipcMain.handle("db:save-message", (_event, content) => {
    const stmt = db.prepare("INSERT INTO messages (content) VALUES (?)");
    const info = stmt.run(content);
    return info.lastInsertRowid;
  });
  electron.ipcMain.handle("db:get-messages", () => {
    const stmt = db.prepare("SELECT * FROM messages");
    return stmt.all();
  });
  electron.ipcMain.handle("win:open-chat", (_event, chatId, chatName) => {
    const chatWin = new electron.BrowserWindow({
      width: 400,
      height: 600,
      minWidth: 320,
      minHeight: 400,
      title: `Chat mit ${chatName}`,
      autoHideMenuBar: true,
      // Menüleiste ausblenden (Windows/Linux)
      webPreferences: {
        nodeIntegration: false,
        contextIsolation: true,
        // Wir nutzen denselben Preload wie das Hauptfenster
        preload: path.join(__dirname, "preload.cjs")
      }
    });
    electron.ipcMain.handle("win:dock-chat", (event, chatId2, chatName2) => {
      const senderWin = electron.BrowserWindow.fromWebContents(event.sender);
      if (win) {
        win.webContents.send("chat-docked-back", chatId2, chatName2);
      }
      if (senderWin && !senderWin.isDestroyed()) {
        senderWin.close();
      }
    });
    const popupUrl = process.env.VITE_DEV_SERVER_URL ? `${process.env.VITE_DEV_SERVER_URL}/#/popout/${chatId}?name=${encodeURIComponent(chatName)}` : `file://${path.join(__dirname, "../dist/index.html")}#/popout/${chatId}?name=${encodeURIComponent(chatName)}`;
    chatWin.loadURL(popupUrl);
  });
} catch (error) {
  console.error("Initialisierungs-Fehler:", error);
}
process.env.DIST = path.join(__dirname, "../dist");
process.env.VITE_PUBLIC = electron.app.isPackaged ? process.env.DIST : path.join(process.env.DIST, "../public");
function createWindow() {
  win = new electron.BrowserWindow({
    width: 1400,
    height: 900,
    webPreferences: {
      nodeIntegration: false,
      contextIsolation: true,
      preload: path.join(__dirname, "preload.cjs")
    }
  });
  if (process.env.VITE_DEV_SERVER_URL) {
    win.loadURL(process.env.VITE_DEV_SERVER_URL);
  } else {
    win.loadFile(path.join(process.env.DIST, "index.html"));
  }
}
electron.app.whenReady().then(createWindow);
electron.app.on("window-all-closed", () => {
  win = null;
  if (process.platform !== "darwin")
    electron.app.quit();
});
electron.app.on("activate", () => {
  if (electron.BrowserWindow.getAllWindows().length === 0) {
    createWindow();
  }
});
//# sourceMappingURL=main.cjs.map
