"use strict";
const electron = require("electron");
electron.contextBridge.exposeInMainWorld("electron", {
  // ... deine alten Funktionen ...
  saveMessage: (content) => electron.ipcRenderer.invoke("db:save-message", content),
  getMessages: () => electron.ipcRenderer.invoke("db:get-messages"),
  openChatWindow: (chatId, chatName) => electron.ipcRenderer.invoke("win:open-chat", chatId, chatName),
  // --- NEU ---
  dockChatWindow: (chatId, chatName) => electron.ipcRenderer.invoke("win:dock-chat", chatId, chatName),
  // Listener: Das Hauptfenster hört hier zu.
  // Wir filtern das Electron-Event-Objekt (_event) raus und geben nur die Daten weiter.
  onChatDocked: (callback) => {
    electron.ipcRenderer.on("chat-docked-back", (_event, chatId, chatName) => callback(chatId, chatName));
  }
});
//# sourceMappingURL=preload.cjs.map
